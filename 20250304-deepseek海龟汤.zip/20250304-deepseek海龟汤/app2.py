import streamlit as st
from streamlit_option_menu import option_menu
import os
from dotenv import load_dotenv
import requests

# 页面配置
st.set_page_config(
    page_title="海龟汤推理游戏",
    page_icon="🐢",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# 加载环境变量
load_dotenv()

# 初始化session state
if 'api_key' not in st.session_state:
    st.session_state.api_key = None

# 设置 Deepseek API URL
DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"

# 自定义CSS样式
st.markdown("""
    <style>
    #MainMenu {visibility: hidden;}
    header {visibility: hidden;}
    footer {visibility: hidden;}
        .stApp {
        max-width: 100%;
        padding: 2rem;
        background: 
                    linear-gradient(rgba(255, 255, 255, 0.7), rgba(255, 255, 255, 0.7)),
                    linear-gradient(135deg, #ffb88c, #de6262);
        background-size: auto 60%, cover, cover;
        background-position: right bottom, center, center;
        background-repeat: no-repeat, repeat, repeat;
        background-attachment: fixed;
    }
    .main {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem;
        background-color: rgba(255, 255, 255, 0.92);
        border-radius: 20px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    }
    .stButton > button {
        width: 100%;
        background-color: #4CAF50;
        color: white;
        border-radius: 10px;
        padding: 0.8rem 2rem;
        border: none;
        transition: all 0.3s ease;
        font-size: 16px;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    .stButton > button:hover {
        background-color: #45a049;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        transform: translateY(-2px);
    }
    .story-card {
        background: rgba(255, 255, 255, 0.95);
        padding: 2.5rem;
        border-radius: 15px;
        border: none;
        margin: 1.5rem 0;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    }
    .section-divider {
        border-top: 2px dashed rgba(255, 255, 255, 0.8);
        margin: 2rem 0;
        width: 100%;
    }
    .response-box {
        background-color: white;
        padding: 1.5rem;
        border-radius: 12px;
        margin-top: 1rem;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        border-left: 4px solid #4CAF50;
    }
    .nav-link {
        color: #2c3e50 !important;
        font-weight: 600;
        padding: 15px 25px !important;
        border-radius: 10px;
        margin: 0 5px;
        transition: all 0.3s ease;
    }
    .nav-link:hover {
        color: #4CAF50 !important;
        background-color: rgba(76, 175, 80, 0.1);
    }
    .nav-link-selected {
        color: #4CAF50 !important;
        background-color: rgba(76, 175, 80, 0.15);
        border-bottom: none !important;
    }
    h1, h2, h3 {
        color: #2c3e50;
        font-weight: 700;
        margin-bottom: 1.5rem;
    }
    .developer-banner {
        text-align: center;
        padding: 1.5rem;
        margin-bottom: 2rem;
        background: rgba(255, 255, 255, 0.95);
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    }
    .developer-name {
        font-size: 26px;
        font-weight: 700;
        color: #2c3e50;
        letter-spacing: 1.5px;
    }
    .developer-name span {
        color: #4CAF50;
        background: linear-gradient(120deg, #4CAF50, #45a049);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    .stTextInput > div > div > input {
        border-radius: 10px;
        padding: 1rem;
        font-size: 16px;
        border: 2px solid #e9ecef;
    }
    .stTextArea > div > div > textarea {
        border-radius: 10px;
        padding: 1rem;
        font-size: 16px;
        border: 2px solid #e9ecef;
    }
    .stAlert {
        background-color: white;
        border-radius: 10px;
        padding: 1rem;
        border-left: 4px solid #4CAF50;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    }
    </style>
""", unsafe_allow_html=True)

# 在CSS样式之后，API函数之前添加开发者信息
st.markdown("""
    <div class='developer-banner'>
        <div class='developer-name'>
            Developed by <span>Kkellyoffical</span> 🚀
        </div>
    </div>
""", unsafe_allow_html=True)

def generate_turtle_soup(keywords):
    """根据关键词生成海龟汤故事和答案"""
    try:
        if not st.session_state.api_key:
            return "请先设置API密钥", ""
            
        headers = {
            "Authorization": f"Bearer {st.session_state.api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": "你是一个专业的海龟汤谜题创作者。请创作简洁有趣的海龟汤谜题。"},
                {"role": "user", "content": f"请根据以下关键词创作一个海龟汤谜题：{keywords}。请提供：\n1. 故事：一个简短但充满谜团的故事\n2. 答案：对故事真相的简明解释\n\n请直接以'故事：'和'答案：'开头分别给出内容，不要有其他多余的文字。"}
            ],
            "temperature": 1.0,
            "max_tokens": 1000
        }
        
        response = requests.post(DEEPSEEK_API_URL, headers=headers, json=data)
        response.raise_for_status()
        full_response = response.json()["choices"][0]["message"]["content"]
        
        parts = full_response.split("答案：")
        if len(parts) >= 2:
            story = parts[0].replace("故事：", "").strip()
            answer = parts[1].strip()
            return story, answer
        else:
            return full_response, "无法分离答案，请重新生成"
    
    except Exception as e:
        return f"生成失败: {str(e)}", ""

def evaluate_guess(guess, answer):
    """评估猜测与答案的相似度"""
    try:
        if not st.session_state.api_key:
            return "请先设置API密钥"
            
        headers = {
            "Authorization": f"Bearer {st.session_state.api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": "你是一个公正的海龟汤评判员。不要透露完整答案，只需评估玩家猜测的方向是否正确。"},
                {"role": "user", "content": f"请评估以下猜测的正确程度，给出0-100的分数，并给出委婉的提示。不要透露具体答案。\n\n答案：{answer}\n\n猜测：{guess}"}
            ],
            "temperature": 0.3,
            "max_tokens": 500
        }
        
        response = requests.post(DEEPSEEK_API_URL, headers=headers, json=data)
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]
    
    except Exception as e:
        return f"评估失败: {str(e)}"

def get_hint(answer):
    """获取提示"""
    try:
        if not st.session_state.api_key:
            return "请先设置API密钥"
            
        headers = {
            "Authorization": f"Bearer {st.session_state.api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": "你是一个海龟汤游戏的提示者，需要给出委婉的提示而不能透露答案。"},
                {"role": "user", "content": f"请根据以下答案生成一个委婉的提示，帮助玩家思考但不要透露具体答案：\n\n答案：{answer}"}
            ],
            "temperature": 0.7,
            "max_tokens": 300
        }
        
        response = requests.post(DEEPSEEK_API_URL, headers=headers, json=data)
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]
    
    except Exception as e:
        return f"获取提示失败: {str(e)}"

def answer_question(question, story, answer):
    """回答玩家的问题"""
    try:
        if not st.session_state.api_key:
            return "请先设置API密钥"
            
        headers = {
            "Authorization": f"Bearer {st.session_state.api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": "你是一个海龟汤游戏的裁判。你需要根据故事和答案，对玩家提出的一般疑问句（只要是能回答是与否的就是一般疑问句）回答'是'或'否'；如果你觉得与问题无关请回复'与故事无关'，如果问题不是一般疑问句，请回复'这不是一个一般疑问句，请用是非问句提问。'"},
                {"role": "user", "content": f"根据以下故事和答案，回答玩家的问题。\n\n故事：{story}\n\n答案：{answer}\n\n玩家问题：{question}"}
            ],
            "temperature": 0.3,
            "max_tokens": 100
        }
        
        response = requests.post(DEEPSEEK_API_URL, headers=headers, json=data)
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]
    
    except Exception as e:
        return f"回答失败: {str(e)}"

# 导航栏样式配置
selected = option_menu(
    menu_title=None,
    options=["🏠 主页", "🎮 开始游戏", "📚 历史记录", "ℹ️ 关于"],
    icons=["house", "controller", "clock-history", "info-circle"],
    menu_icon="cast",
    default_index=0,
    orientation="horizontal",
    styles={
        "container": {
            "padding": "10px",
            "background-color": "rgba(255, 255, 255, 0.8)",
            "border-radius": "50px",
            "margin-bottom": "20px",
            "box-shadow": "0 4px 15px rgba(0, 0, 0, 0.05)"
        },
        "icon": {
            "color": "#2c3e50",
            "font-size": "20px"
        },
        "nav-link": {
            "font-size": "16px",
            "text-align": "center",
            "margin": "0px 10px",
            "padding": "10px 20px",
            "border-radius": "30px",
            "transition": "all 0.3s ease",
            "--hover-color": "rgba(76, 175, 80, 0.1)"
        },
        "nav-link-selected": {
            "background": "linear-gradient(90deg, #4CAF50, #2E7D32)",
            "color": "white !important",
            "box-shadow": "0 4px 15px rgba(76, 175, 80, 0.3)"
        }
    }
)

# 主页内容
if selected == "🏠 主页":
    st.markdown("<h1 style='text-align: center; color: #2c3e50;'>🐢 欢迎来到海龟汤推理游戏</h1>", unsafe_allow_html=True)
    st.markdown("<p style='text-align: center; color: #666; font-size: 18px;'>一起来体验智慧与推理的乐趣吧！</p>", unsafe_allow_html=True)
    
    # 添加API密钥输入框
    col1, col2, col3 = st.columns([1,2,1])
    with col2:
        st.markdown("""
        <div style='background: rgba(255, 255, 255, 0.9); padding: 2.5rem; border-radius: 20px; text-align: center; box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1); border-left: 5px solid #4CAF50;'>
            <h2 style='color: #2c3e50; margin-bottom: 1.5rem;'>设置API密钥</h2>
        """, unsafe_allow_html=True)
        api_input = st.text_input("请输入您的 Deepseek API 密钥", type="password", key="api_key_input")
        if st.button("保存 API 密钥", key="save_api_key"):
            if api_input:
                st.session_state.api_key = api_input
                st.success("API 密钥已保存！")
            else:
                st.error("请输入 API 密钥")
        st.markdown("</div>", unsafe_allow_html=True)

        if st.session_state.api_key:
            st.markdown("""
            <div style='background: rgba(255, 255, 255, 0.9); padding: 2.5rem; border-radius: 20px; text-align: center; box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1); border-left: 5px solid #4CAF50;'>
                <h2 style='color: #2c3e50; margin-bottom: 1.5rem;'>游戏规则</h2>
                <p style='color: #666; font-size: 16px; margin: 1rem 0;'>1. 输入关键词生成谜题</p>
                <p style='color: #666; font-size: 16px; margin: 1rem 0;'>2. 仔细阅读故事内容</p>
                <p style='color: #666; font-size: 16px; margin: 1rem 0;'>3. 通过提问和思考找出真相</p>
                <p style='color: #666; font-size: 16px; margin: 1rem 0;'>4. 提交你的猜测获得评分</p>
            </div>
            """, unsafe_allow_html=True)

# 游戏页面
elif selected == "🎮 开始游戏":
    if not st.session_state.api_key:
        st.error("请先在主页设置您的 API 密钥！")
    else:
        st.markdown("<h2 style='text-align: center; color: #2c3e50;'>🎮 创建新的海龟汤</h2>", unsafe_allow_html=True)
        
        col1, col2, col3 = st.columns([1,2,1])
        with col2:
            keywords = st.text_input("✨ 输入关键词", placeholder="例如：月亮、秘密、误会", key="keywords_input")
            if st.button("🎲 生成海龟汤", key="generate_button"):
                if keywords:
                    with st.spinner("🎨 正在创作海龟汤..."):
                        story, answer = generate_turtle_soup(keywords)
                        st.session_state.story = story
                        st.session_state.answer = answer
                        st.session_state.has_story = True
                else:
                    st.error("请输入关键词")

        if 'has_story' in st.session_state and st.session_state.has_story:
            # 显示故事
            st.markdown("<div class='story-card'>", unsafe_allow_html=True)
            st.markdown("<h3 style='text-align: center;'>📖 海龟汤故事</h3>", unsafe_allow_html=True)
            st.write(st.session_state.story)
            st.markdown("</div>", unsafe_allow_html=True)

            # 添加显示答案按钮
            col1, col2, col3 = st.columns([1,2,1])
            with col2:
                if st.button("🔍 显示答案", key="show_answer_button", type="secondary"):
                    st.markdown(f"""
                        <div class="response-box" style="border-left: 4px solid #de6262;">
                            <h4 style='text-align: center; color: #de6262;'>🎯 故事真相</h4>
                            <p>{st.session_state.answer}</p>
                        </div>
                    """, unsafe_allow_html=True)

            # 提问功能
            st.markdown("<div class='story-card'>", unsafe_allow_html=True)
            st.markdown("<h3 style='text-align: center;'>❓ 提出问题</h3>", unsafe_allow_html=True)
            st.markdown("<p style='text-align: center; color: #666;'>请提出一般疑问句（可用'是否'、'有没有'等词开头）</p>", unsafe_allow_html=True)
            
            col1, col2, col3 = st.columns([1,2,1])
            with col2:
                question = st.text_input("", placeholder="例如：这件事是发生在晚上吗？", key="question_input")
                if st.button("🤔 提问", key="ask_button"):
                    if question:
                        with st.spinner("思考中..."):
                            answer = answer_question(question, st.session_state.story, st.session_state.answer)
                            st.markdown(f"""
                                <div class="response-box">
                                    <h4 style='text-align: center;'>🎯 回答</h4>
                                    <p>{answer}</p>
                                </div>
                            """, unsafe_allow_html=True)
                    else:
                        st.error("请输入问题")
            st.markdown("</div>", unsafe_allow_html=True)

            # 提示功能
            col1, col2, col3 = st.columns([1,2,1])
            with col2:
                if st.button("💡 获取提示", key="hint_button"):
                    hint = get_hint(st.session_state.answer)
                    st.markdown(f"""
                        <div class="response-box">
                            <h4 style='text-align: center;'>💡 提示</h4>
                            <p>{hint}</p>
                        </div>
                    """, unsafe_allow_html=True)
            
            # 猜测功能
            st.markdown("<div class='story-card'>", unsafe_allow_html=True)
            st.markdown("<h3 style='text-align: center;'>🤔 猜测故事真相</h3>", unsafe_allow_html=True)
            
            col1, col2, col3 = st.columns([1,2,1])
            with col2:
                guess = st.text_area("", placeholder="在这里输入你的猜测...", height=100, key="guess_input")
                if st.button("🎯 提交猜测", key="submit_guess_button"):
                    if guess:
                        with st.spinner("正在评估..."):
                            evaluation = evaluate_guess(guess, st.session_state.answer)
                            st.markdown(f"""
                                <div class="response-box">
                                    <h4 style='text-align: center;'>📝 评估结果</h4>
                                    <p>{evaluation}</p>
                                </div>
                            """, unsafe_allow_html=True)
                            
                            if "90" in evaluation or "95" in evaluation or "100" in evaluation:
                                st.balloons()
                                st.success("🎉 恭喜你接近真相！")
                    else:
                        st.error("请输入你的猜测")
            st.markdown("</div>", unsafe_allow_html=True)

# 历史记录页面
elif selected == "📚 历史记录":
    st.markdown("<h2 style='text-align: center; color: #2c3e50;'>📚 游戏历史</h2>", unsafe_allow_html=True)
    st.markdown("""
    <div class='story-card'>
        <h3 style='text-align: center; color: #4CAF50;'>🚧 功能开发中</h3>
        <p style='text-align: center; color: #666; font-size: 18px;'>历史记录功能即将推出，敬请期待！</p>
    </div>
    """, unsafe_allow_html=True)

# 关于页面
elif selected == "ℹ️ 关于":
    st.markdown("<h2 style='text-align: center; color: #2c3e50;'>ℹ️ 关于海龟汤</h2>", unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([1,2,1])
    with col2:
        st.markdown("""
        <div class='story-card'>
            <h3>什么是海龟汤？</h3>
            <p style='color: #666; font-size: 16px; line-height: 1.8;'>海龟汤是一种源自日本的推理游戏。玩家需要通过提问和思考，揭开故事背后的真相。每个故事都包含着独特的谜题，需要玩家运用逻辑思维和创意想象来解开谜团。</p>
            <h3 style='margin-top: 2rem;'>游戏特点</h3>
            <ul style='color: #666; font-size: 16px; line-height: 1.8; list-style-type: none; padding-left: 0;'>
                <li style="margin: 0.8rem 0;">❤️ 智力挑战：锻炼思维想象力</li>
                <li style="margin: 0.8rem 0;">🎯 创意思维：培养发散思维</li>
                <li style="margin: 0.8rem 0;">🔍 逻辑推理：提升分析力</li>
                <li style="margin: 0.8rem 0;">🎮 趣味游戏：寓教于乐</li>
            </ul>
            <h3 style='margin-top: 2rem;'>游戏技巧</h3>
            <ol style='color: #666; font-size: 16px; line-height: 1.8; margin-bottom: 0;'>
                <li style="margin: 0.8rem 0;">打破思维定式</li>
                <li style="margin: 0.8rem 0;">加强分析推理</li>
                <li style="margin: 0.8rem 0;">提升逻辑思维</li>
                <li style="margin: 0.8rem 0;">培养发散思维</li>
            </ol>
        </div>
        """, unsafe_allow_html=True)