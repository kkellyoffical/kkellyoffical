import subprocess
import os
import sys
import webbrowser
import time

def find_python_path():
    """从环境变量中查找Python解释器路径"""
    # 首先检查当前Python解释器路径
    if sys.executable and os.path.exists(sys.executable):
        return sys.executable
    
    # 从PATH环境变量中查找python.exe
    paths = os.environ.get("PATH", "").split(os.pathsep)
    python_names = ["python.exe", "python3.exe"]
    
    for path in paths:
        for python_name in python_names:
            python_path = os.path.join(path, python_name)
            if os.path.exists(python_path):
                return python_path
    
    # 如果都找不到，返回默认的python命令
    return "python"

if __name__ == "__main__":
    # 设置工作目录
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    # 获取Python解释器路径
    python_path = find_python_path()
    
    # 启动 Streamlit 应用
    process = subprocess.Popen([
        python_path, "-m", "streamlit", "run",
        "app2.py",
        "--server.address", "localhost",
        "--server.port", "8501",
        "--browser.serverAddress", "localhost",
        "--server.headless", "true"
    ])
    
    # 等待服务启动
    time.sleep(3)
    
    # 打开浏览器
    webbrowser.open('http://localhost:8501')
    
    # 等待进程结束
    process.wait()